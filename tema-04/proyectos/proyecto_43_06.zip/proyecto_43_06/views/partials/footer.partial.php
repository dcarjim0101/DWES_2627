<!-- pie de página de la aplicación -->
<footer class="footer mt-auto py-3 fixed-bottom bg-light">
    <div class="container">
        <span class="text-muted">&copy; 2026
            David Carrero Jiménez - DWES - 2º DAW - Curso 26/27
        </span>
    </div>
</footer>